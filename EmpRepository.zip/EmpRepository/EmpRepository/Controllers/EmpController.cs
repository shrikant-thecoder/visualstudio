﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmpRepository.DAL;

namespace EmpRepository.Controllers
{
    public class EmpController : Controller
    {
        EmployeeRepository repository = new EmployeeRepository();
        //IEmp iemp;
        // GET: Emp
        public ActionResult Index()
        {
            return View(repository.GetData());
        }

        // GET: Emp/Details/5
        public ActionResult Details(int id)
        {
            return View(repository.GetDataById(id));
        }

        // GET: Emp/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Emp/Create
        [HttpPost]
        public ActionResult Create([Bind(Include = "EmpNo,EmpName,Salary,DeptCode")]Emp emp)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    repository.InsertEmp(emp);
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Emp/Edit/5
        public ActionResult Edit(int id)
        {
            return View(repository.GetDataById(id));
        }

        // POST: Emp/Edit/5
        [HttpPost]
        public ActionResult Edit([Bind(Include = "EmpNo,EmpName,Salary,DeptCode")]Emp emp)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    repository.UpdateEmp(emp);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Emp/Delete/5
        public ActionResult Delete(int id)
        {
            return View(repository.GetDataById(id));
        }

        // POST: Emp/Delete/5
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                // TODO: Add delete logic here
                repository.DeleteEmp(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}