﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpRepository.DAL
{
    interface IEmpRepository
    {
        List<Emp> GetData();

        void InsertEmp(Emp emp);

        void UpdateEmp(Emp emp);

        Emp GetDataById(int id);

        void DeleteEmp(int id);

    }
}
