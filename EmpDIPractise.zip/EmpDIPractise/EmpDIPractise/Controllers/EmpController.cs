﻿using EmpDIPractise.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmpDIPractise.Controllers
{
    public class EmpController : Controller
    {
        IEmpRepository iemp;
        public EmpController(IEmpRepository iemp)
        {
            this.iemp = iemp;
        }
        // GET: Emp
        public ActionResult Index()
        {
            return View(iemp.GetData());
        }

        // GET: Emp/Details/5
        public ActionResult Details(int id)
        {
            return View(iemp.GetDataById(id));
        }

        // GET: Emp/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Emp/Create
        [HttpPost]
        public ActionResult Create([Bind(Include = "EmpNo,EmpName,Salary,DeptCode")]Emp emp)
        {
            try
            {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    iemp.InsertEmp(emp);
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Emp/Edit/5
        public ActionResult Edit(int id)
        {
            return View(iemp.GetDataById(id));
        }

        // POST: Emp/Edit/5
        [HttpPost]
        public ActionResult Edit([Bind(Include = "EmpNo,EmpName,Salary,DeptCode")]Emp emp)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    iemp.UpdateEmp(emp);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Emp/Delete/5
        public ActionResult Delete(int id)
        {
            return View(iemp.GetDataById(id));
        }

        // POST: Emp/Delete/5
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                // TODO: Add delete logic here
                iemp.DeleteEmp(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}