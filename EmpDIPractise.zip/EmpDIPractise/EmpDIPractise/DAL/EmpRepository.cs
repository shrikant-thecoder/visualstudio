﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace EmpDIPractise.DAL
{
    public class EmpRepository:IEmpRepository
    {
        PayrollEntities entity = new PayrollEntities();
        public List<Emp> GetData()
        {
            return entity.Emps.ToList();
        }
        public void InsertEmp(Emp emp)
        {
            entity.Emps.Add(emp);
            entity.SaveChanges();
        }

        public void UpdateEmp(Emp emp)
        {
            entity.Entry(emp).State = EntityState.Modified;
            entity.SaveChanges();
        }


        public Emp GetDataById(int id)
        {
            return entity.Emps.Find(id);
        }

        public void DeleteEmp(int id)
        {
            Emp emp = entity.Emps.Find(id);
            entity.Emps.Remove(emp);
            entity.SaveChanges();
        }
    }
}